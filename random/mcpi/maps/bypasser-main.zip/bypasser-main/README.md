# Bypass captcha with Puppeteer
